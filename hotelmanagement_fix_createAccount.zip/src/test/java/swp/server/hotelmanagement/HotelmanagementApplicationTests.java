package swp.server.hotelmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import swp.server.hotelmanagement.controllers.AccountControllerTest;
import swp.server.hotelmanagement.controllers.BlogControllerTest;
import swp.server.hotelmanagement.controllers.RoomControllerTest;
import swp.server.hotelmanagement.controllers.ServiceControllerTest;

@SpringBootTest
class HotelmanagementApplicationTests {




	@Test
	void contextLoads() {
//
	}

}
